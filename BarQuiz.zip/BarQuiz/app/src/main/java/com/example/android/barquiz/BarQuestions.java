package com.example.android.barquiz;

public class BarQuestions {

    private String mQuestions [] = {
            "How many liquors are in a Long Island Iced Tea?",
            "What classy cocktail famously has an olive as a garnish?",
            "What special ingredient is used to create the red color at the bottom of a Tequila Sunrise",
            "What kind of glass is used for a Pina Colada?",
            "What are some common fruit garnishes used in many different cocktails?",
            "How does James Bond like his Vesper Martini?",
            "Can you name this sweet yet minty drink said to be a favorite of Ernest Hemingway?",
            "What are some bar accessories?",
            "What is the spanish translation for Rum and Coke?",
            "What is the literal meaning of this translation?",
    };

}
