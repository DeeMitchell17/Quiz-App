package com.example.android.barquiz;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button reset;
    RadioButton questionOne_5;
    RadioButton questionTwo_martini;
    RadioButton questionThree_grenadineSyrup;
    RadioButton questionFour_hurricaneGlass;
    CheckBox questionFive_lemon;
    CheckBox questionFive_grapes;
    CheckBox questionFive_lime;
    CheckBox questionFive_blueberries;
    EditText questionSix_answer;
    RadioButton questionSeven_mojito;
    CheckBox questionEight_screwdriver;
    CheckBox questionEight_shaker;
    CheckBox questionEight_hammer;
    CheckBox questionEight_strainer;
    EditText questionNine_answer;
    EditText questionTen_answer;
    EditText name;

    int runningScore = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void submitAnswers(View view){

        runningScore = 0;


        questionOne_5 = (RadioButton) findViewById(R.id.five);
        questionOne_5.isChecked();
        if(questionOne_5.isChecked()){
            runningScore++;
        }


        questionTwo_martini = (RadioButton) findViewById(R.id.martini);
        questionTwo_martini.isChecked();
        if(questionTwo_martini.isChecked()){
            runningScore++;
        }


        questionThree_grenadineSyrup = (RadioButton) findViewById(R.id.grenadine_syrup);
        questionThree_grenadineSyrup.isChecked();
        if(questionThree_grenadineSyrup.isChecked()){
            runningScore++;
        }


        questionFour_hurricaneGlass = (RadioButton) findViewById(R.id.hurricane_glass);
        questionFour_hurricaneGlass.isChecked();
        if(questionFour_hurricaneGlass.isChecked()){
            runningScore++;
        }


        questionFive_lemon = (CheckBox) this.findViewById(R.id.lemon);
        questionFive_grapes = (CheckBox) this.findViewById(R.id.grapes);
        questionFive_lime = (CheckBox) this.findViewById(R.id.lime);
        questionFive_blueberries = (CheckBox) this.findViewById(R.id.blueberries);
        if ((questionFive_lemon.isChecked() && questionFive_lime.isChecked())) {
            runningScore++;
        }


        questionSix_answer = (EditText) findViewById(R.id.questionSix_answer);
        if(questionSix_answer.getText().toString().equals("Shaken, not stirred") || questionSix_answer.getText().toString().equals("shaken not stirred") || questionSix_answer.getText().toString().equals("shaken") ){
            runningScore++;
        }


        questionSeven_mojito = (RadioButton) findViewById(R.id.mojito);
        questionSeven_mojito.isChecked();
        if(questionSeven_mojito.isChecked()){
            runningScore++;
        }


        questionEight_screwdriver = (CheckBox) this.findViewById(R.id.screwdriver);
        questionEight_shaker = (CheckBox) this.findViewById(R.id.shaker);
        questionEight_hammer = (CheckBox) this.findViewById(R.id.hammer);
        questionEight_strainer = (CheckBox) this.findViewById(R.id.strainer);
        if ((questionEight_shaker.isChecked() && questionEight_strainer.isChecked())) {
            runningScore++;
        }


        questionNine_answer = (EditText) findViewById(R.id.questionNine_answer);
        if(questionNine_answer.getText().toString().equals("Cuba Libre") || questionNine_answer.getText().toString().equals("cuba libre")){
            runningScore++;
        }


        questionTen_answer = (EditText) findViewById(R.id.questionTen_answer);
        if(questionTen_answer.getText().toString().equals("Free cuba") || questionTen_answer.getText().toString().equals("free cuba")){
            runningScore++;
        }


        EditText nameField = (EditText) findViewById(R.id.name_field);
        String name = nameField.getText().toString();


        String resultsMessage = name + ", You got " + runningScore + " out of 10 correct.";
        Toast.makeText(this, resultsMessage, Toast.LENGTH_LONG).show();

    }


    public void resetScore(View view) {
        questionOne_5.setChecked(false);
        questionTwo_martini.setChecked(false);
        questionThree_grenadineSyrup.setChecked(false);
        questionFour_hurricaneGlass.setChecked(false);
        questionFive_lemon.toggle();
        questionFive_lime.toggle();
        questionSix_answer.setText("");
        questionSeven_mojito.setChecked(false);
        questionEight_shaker.toggle();
        questionEight_strainer.toggle();
        questionNine_answer.setText("");
        questionTen_answer.setText("");

    }
}
